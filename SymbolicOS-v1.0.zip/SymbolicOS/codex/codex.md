# Codex Placeholder
Documenting glyphs and rituals.
