# 📜 Changelog

## [v1.0] - First Public Release

### Added
- Mirror UI (Kivy)
- Ritual Engine
- Symbolic Firmware
- Glyph metadata
- Codex generator
