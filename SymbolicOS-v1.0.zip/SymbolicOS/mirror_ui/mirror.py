# Kivy UI Placeholder for Mirror
