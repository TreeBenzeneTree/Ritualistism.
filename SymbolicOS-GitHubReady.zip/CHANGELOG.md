# 📜 Changelog

## [v1.1] - Dream Ritual Expansion

### Added
- 🌌 Dream Ritual Generator
- 🧠 Glyph Soul Memory
- 🪙 Symbolic Economy Engine
- 🔁 Resurrection Logic
- 🛠️ Mirror UI Upgrades

### Changed
- Ritual compiler with loop support

### Fixed
- Large Codex load bugs
