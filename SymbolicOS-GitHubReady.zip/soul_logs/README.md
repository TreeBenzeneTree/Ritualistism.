# Soul_logs Module

This folder contains the soul_logs files.