# Symbolic Temple OS
A symbolic ritual operating system by Ebenezer Isaac Okwodu.